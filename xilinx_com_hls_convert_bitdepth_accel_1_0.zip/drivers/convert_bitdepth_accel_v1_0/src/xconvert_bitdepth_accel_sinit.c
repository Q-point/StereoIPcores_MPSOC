// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xconvert_bitdepth_accel.h"

extern XConvert_bitdepth_accel_Config XConvert_bitdepth_accel_ConfigTable[];

XConvert_bitdepth_accel_Config *XConvert_bitdepth_accel_LookupConfig(u16 DeviceId) {
	XConvert_bitdepth_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCONVERT_BITDEPTH_ACCEL_NUM_INSTANCES; Index++) {
		if (XConvert_bitdepth_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XConvert_bitdepth_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XConvert_bitdepth_accel_Initialize(XConvert_bitdepth_accel *InstancePtr, u16 DeviceId) {
	XConvert_bitdepth_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XConvert_bitdepth_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XConvert_bitdepth_accel_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

