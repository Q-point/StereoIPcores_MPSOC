// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCONVERT_BITDEPTH_ACCEL_H
#define XCONVERT_BITDEPTH_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xconvert_bitdepth_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XConvert_bitdepth_accel_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XConvert_bitdepth_accel;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XConvert_bitdepth_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XConvert_bitdepth_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XConvert_bitdepth_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XConvert_bitdepth_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XConvert_bitdepth_accel_Initialize(XConvert_bitdepth_accel *InstancePtr, u16 DeviceId);
XConvert_bitdepth_accel_Config* XConvert_bitdepth_accel_LookupConfig(u16 DeviceId);
int XConvert_bitdepth_accel_CfgInitialize(XConvert_bitdepth_accel *InstancePtr, XConvert_bitdepth_accel_Config *ConfigPtr);
#else
int XConvert_bitdepth_accel_Initialize(XConvert_bitdepth_accel *InstancePtr, const char* InstanceName);
int XConvert_bitdepth_accel_Release(XConvert_bitdepth_accel *InstancePtr);
#endif

void XConvert_bitdepth_accel_Start(XConvert_bitdepth_accel *InstancePtr);
u32 XConvert_bitdepth_accel_IsDone(XConvert_bitdepth_accel *InstancePtr);
u32 XConvert_bitdepth_accel_IsIdle(XConvert_bitdepth_accel *InstancePtr);
u32 XConvert_bitdepth_accel_IsReady(XConvert_bitdepth_accel *InstancePtr);
void XConvert_bitdepth_accel_EnableAutoRestart(XConvert_bitdepth_accel *InstancePtr);
void XConvert_bitdepth_accel_DisableAutoRestart(XConvert_bitdepth_accel *InstancePtr);

void XConvert_bitdepth_accel_Set_height(XConvert_bitdepth_accel *InstancePtr, u32 Data);
u32 XConvert_bitdepth_accel_Get_height(XConvert_bitdepth_accel *InstancePtr);
void XConvert_bitdepth_accel_Set_width(XConvert_bitdepth_accel *InstancePtr, u32 Data);
u32 XConvert_bitdepth_accel_Get_width(XConvert_bitdepth_accel *InstancePtr);

void XConvert_bitdepth_accel_InterruptGlobalEnable(XConvert_bitdepth_accel *InstancePtr);
void XConvert_bitdepth_accel_InterruptGlobalDisable(XConvert_bitdepth_accel *InstancePtr);
void XConvert_bitdepth_accel_InterruptEnable(XConvert_bitdepth_accel *InstancePtr, u32 Mask);
void XConvert_bitdepth_accel_InterruptDisable(XConvert_bitdepth_accel *InstancePtr, u32 Mask);
void XConvert_bitdepth_accel_InterruptClear(XConvert_bitdepth_accel *InstancePtr, u32 Mask);
u32 XConvert_bitdepth_accel_InterruptGetEnabled(XConvert_bitdepth_accel *InstancePtr);
u32 XConvert_bitdepth_accel_InterruptGetStatus(XConvert_bitdepth_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
