// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xconvert_bitdepth_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XConvert_bitdepth_accel_CfgInitialize(XConvert_bitdepth_accel *InstancePtr, XConvert_bitdepth_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XConvert_bitdepth_accel_Start(XConvert_bitdepth_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XConvert_bitdepth_accel_IsDone(XConvert_bitdepth_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XConvert_bitdepth_accel_IsIdle(XConvert_bitdepth_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XConvert_bitdepth_accel_IsReady(XConvert_bitdepth_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XConvert_bitdepth_accel_EnableAutoRestart(XConvert_bitdepth_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XConvert_bitdepth_accel_DisableAutoRestart(XConvert_bitdepth_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XConvert_bitdepth_accel_Set_height(XConvert_bitdepth_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XConvert_bitdepth_accel_Get_height(XConvert_bitdepth_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XConvert_bitdepth_accel_Set_width(XConvert_bitdepth_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XConvert_bitdepth_accel_Get_width(XConvert_bitdepth_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XConvert_bitdepth_accel_InterruptGlobalEnable(XConvert_bitdepth_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_GIE, 1);
}

void XConvert_bitdepth_accel_InterruptGlobalDisable(XConvert_bitdepth_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_GIE, 0);
}

void XConvert_bitdepth_accel_InterruptEnable(XConvert_bitdepth_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_IER);
    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_IER, Register | Mask);
}

void XConvert_bitdepth_accel_InterruptDisable(XConvert_bitdepth_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_IER);
    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XConvert_bitdepth_accel_InterruptClear(XConvert_bitdepth_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConvert_bitdepth_accel_WriteReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_ISR, Mask);
}

u32 XConvert_bitdepth_accel_InterruptGetEnabled(XConvert_bitdepth_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_IER);
}

u32 XConvert_bitdepth_accel_InterruptGetStatus(XConvert_bitdepth_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConvert_bitdepth_accel_ReadReg(InstancePtr->Control_BaseAddress, XCONVERT_BITDEPTH_ACCEL_CONTROL_ADDR_ISR);
}

